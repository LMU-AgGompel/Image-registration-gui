This is a package for image registration using landmarks
